package com.example.pg5;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText uname,pswd;
    Button btn;
    DbHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        uname = findViewById(R.id.editText1);
        pswd = findViewById(R.id.editText2);
        btn = findViewById(R.id.button);


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = uname.getText().toString();
                String password = pswd.getText().toString();
                int id = checkUser(new User(name, password));
                if (id == -1) {
                    Toast.makeText(MainActivity.this, "User does not Exist", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(MainActivity.this, "Username" + name + "Exist", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(MainActivity.this, Second2Activity.class);
                    startActivity(i);
                }
            }


        });
        db=new DbHandler(MainActivity.this);
        db.addUser(new User("deepika","123"));
        db.addUser(new User("Free","software"));


//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
//
//            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
//            return insets;
//        });
    }
    private int checkUser(User user){
        return db.checkUser(user);
    }


}