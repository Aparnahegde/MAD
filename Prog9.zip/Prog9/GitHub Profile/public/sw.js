(function(){
    self.addEventListener('install',event=>{
        console.log("sw is instllaing");
        self.waitUntil(
            caches
            .open('PWD_app')
            .then(cache=>cache.addAll(['/git'])))
            self.skipWaiting();
    })
    self.addEventListener('activate',event=>
    {
        self.waitUntil(caches.delete('PWD_app'));
            console.log("sw is activating");
            
    })
    self.addEventListener('fetch',event=>{
        console.log("Service worker is fetching",event.request.url);
        self.respondWith(
            caches.match(event.request)
            .then(async(response)=>{
                if(response)
                {
                    return response
                }
                let data = fetch(event.request);
                let data_clone = (await data).clone();
                event.waitUntil(caches.open('PWD_app').then(cache=>cache.put(event.request,data_clone)))
                return data;
            })
        )
    })
})




// (function()
// {
// self.addEventListener('install',event=>{
//     console.log("installing");
//     self.waitUntil(
//         caches.open('PWD_app')
//         .then(cache=>cache.addAll(['/git'])))
//         self.skipWaiting();
// })

// self.addEventListener('activate',event=>{
//     console.log("activating");
//     self.waitUntil(caches.delete('PWD_app'))
// })
// self.addEventListener('fetch',event=>{
//     console.log("fetching");
//     self.respondWait(caches
//         .match(event.request).then(async(response)={
//         if(response)
//         {
//             return response
        
//         }
//         let data = fetch(event.request);
//                  let data_clone = (await data).clone();
//                  event.waitUntil(caches.open('PWD_app').then(cache=>cache.put(event.request,data_clone)))
//                  return data;
//         })
//     )
// })
// })